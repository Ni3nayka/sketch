
import smbus
import time
import os
 
bus = smbus.SMBus(1)
SLAVE_ADDRESS = 0x04
 
def request_reading():
    #reading = int(bus.read_byte(SLAVE_ADDRESS))
    #print(reading)
    
    #for i = 1 in range 12:
    d1  = int(bus.read_byte(SLAVE_ADDRESS))
    d2  = int(bus.read_byte(SLAVE_ADDRESS))
    d3  = int(bus.read_byte(SLAVE_ADDRESS))
    d4  = int(bus.read_byte(SLAVE_ADDRESS))
    d5  = int(bus.read_byte(SLAVE_ADDRESS))
    d6  = int(bus.read_byte(SLAVE_ADDRESS))
    d7  = int(bus.read_byte(SLAVE_ADDRESS))
    d8  = int(bus.read_byte(SLAVE_ADDRESS))
    d9  = int(bus.read_byte(SLAVE_ADDRESS))
    d10 = int(bus.read_byte(SLAVE_ADDRESS))
    d11 = int(bus.read_byte(SLAVE_ADDRESS))
    d12 = int(bus.read_byte(SLAVE_ADDRESS))
    D1 = d1*256*256  + d2*256  + d3
    D2 = d4*256*256  + d5*256  + d6
    D3 = d7*256*256  + d8*256  + d9
    D4 = d10*256*256 + d11*256 + d12
    print(D1, " ", D2, " ", D3, " ", D4)

def request_writing():
    #bus.write_byte(SLAVE_ADDRESS, ord('l'))
    a = input()
    if (a == 'r'):
        request_reading()
    elif (a == 'c'):
        bus.write_byte(SLAVE_ADDRESS, ord('c'))
        print("clean encoder")
    else:
        i = input()
        vvod(a, i)


def map(x, in_min, in_max, out_min, out_max):
    return int((x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min)

def cut(i, a):
    if (abs(i) > a):
        i = abs(i)/i*a
        i = int(i)
    return i

def vvod(a, i):
    i = int(i)
    a = int(a)
    if ((a > 0) and (a < 5)):
        i = cut(i, 100)
        print("motor: ", a, " speed: ", i)
        i = i + 100
        # input arduino
        #i = map(i, -100, 100, 0, 255)
        #print(i)
        bus.write_byte(SLAVE_ADDRESS, a)
        bus.write_byte(SLAVE_ADDRESS, i)
    elif ((a == 5) or (a == 6)):
        i = cut(i, 100)
        print("servo: ", a-4, " angle: ", i)
        i = i + 100
        # input arduino
        bus.write_byte(SLAVE_ADDRESS, a)
        bus.write_byte(SLAVE_ADDRESS, i)
    else :
        print("ERROR vvod")
 
while True:
    #command = input("Enter command: l - toggle LED, r - read A0 ")
    print("Enter command: number for rules motor or <r> for reading encoder")
    request_writing() #transition in <read> in this program 

