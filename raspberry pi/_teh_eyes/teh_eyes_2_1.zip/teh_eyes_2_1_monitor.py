
import smbus
import time
import os
 
bus = smbus.SMBus(1)
SLAVE_ADDRESS = 0x04
 
def request_reading():
    reading = int(bus.read_byte(SLAVE_ADDRESS))
    print(reading)

def request_writing():
    #bus.write_byte(SLAVE_ADDRESS, ord('l'))
    a = input()
    i = input()
    vvod(a, i)


def map(x, in_min, in_max, out_min, out_max):
    return int((x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min)

def cut(i, a):
    if (abs(i) > a):
        i = abs(i)/i*a
        i = int(i)
    return i

def vvod(a, i):
    i = int(i)
    a = int(a)
    if ((a > 0) and (a < 5)):
        i = cut(i, 100)
        i = i + 100
        print("motor: ", a, " speed: ", i)
        # input arduino
        #i = map(i, -100, 100, 0, 255)
        #print(i)
        bus.write_byte(SLAVE_ADDRESS, a)
        bus.write_byte(SLAVE_ADDRESS, i)
    elif ((a == 5) or (a == 6)):
        i = cut(i, 100)
        i = i + 100
        print("servo: ", a-4, " angle: ", i)
        # input arduino
        bus.write_byte(SLAVE_ADDRESS, a)
        bus.write_byte(SLAVE_ADDRESS, i)
    else :
        print("ERROR vvod")
 
while True:
    #command = input("Enter command: l - toggle LED, r - read A0 ")
    print("Enter command: ")
    command = 'l'
    if command == 'l' :
        request_writing()
    elif command == 'r' :
        request_reading()

