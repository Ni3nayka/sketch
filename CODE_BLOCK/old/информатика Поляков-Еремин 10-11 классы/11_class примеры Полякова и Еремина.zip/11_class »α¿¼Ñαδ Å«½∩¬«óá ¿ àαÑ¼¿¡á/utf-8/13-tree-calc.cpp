/*
 Программа к учебнику информатики для 11 класса
 К.Ю. Полякова и Е.А. Еремина.
 Глава 6.
 Программа № 13. Деревья. Вычисление арифметических выражений
*/
#include <iostream>

using namespace std;

typedef struct TNode *PNode;
struct TNode {    
    string data;
    PNode left;
    PNode right;
  };

int Priority ( char op )
{
  switch ( op ) {
    case '+':
    case '-': return 1;
    case '*':
    case '/': return 2;
    }
  return 100;  
}

int LastOp ( string s )
{
  int i, minPrt, res;
  minPrt = 50;
  res = -1;
  for ( i=0; i<s.size(); i++ )
    if ( Priority(s[i]) <= minPrt ) {
      minPrt = Priority(s[i]);
      res = i;
      }
  return res;
}

PNode MakeTree ( string s )
{
  int k;
  PNode Tree; 
  Tree = new struct TNode;
  k = LastOp ( s );
  if ( k == -1 ) {
    Tree->data = s;
    Tree->left = NULL;
    Tree->right = NULL;
    }
  else {
    Tree->data = s.substr ( k, 1);    
    Tree->left = MakeTree ( s.substr(0,k)  );
    Tree->right = MakeTree ( s.substr(k+1) );
}
  return Tree;
}

int Calc ( PNode Tree )
{
  int n1, n2, res;
  if ( Tree->left == NULL )
    res = atoi ( Tree->data.c_str() );
  else {
    n1 = Calc ( Tree->left );
    n2 = Calc ( Tree->right );
    switch ( Tree->data[0] ) {
      case '+': res = n1 + n2; break;
      case '-': res = n1 - n2; break;
      case '*': res = n1 * n2; break;
      case '/': res = n1 / n2; break;
      default: res = 99999;
    }    
  }
  return res;
}

main ()
{
  PNode Tree;
  string s;   
  cout << "Введите арифметическое выражение без скобок: \n";
  cin >> s;
  Tree = MakeTree ( s );
  cout << "Результат: " << Calc(Tree);
     
  cin.get(); cin.get(); 
}
