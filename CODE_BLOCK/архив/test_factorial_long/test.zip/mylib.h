 #ifndef MYLIB_H
 #define MYLIB_H

 int add(int a, int b);
 int rrr();

 #endif
