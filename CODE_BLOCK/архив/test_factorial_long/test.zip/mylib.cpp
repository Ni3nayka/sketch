#include "mylib.h"
#include <iomanip>
#include <iostream>

 int add(int a, int b)
 {
     return a + b;
 }

 int rrr() { return 10; }
