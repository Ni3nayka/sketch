#include <iostream>
#include <iomanip>
using namespace std;

#include <math.h>
#include <cmath>
#include <stdlib.h>
#include "mylib.h"

int main()
{
    //cout << add(1,2);
    cout << rrr();
    cin.get();
    cin.get();
    return 0;
}
