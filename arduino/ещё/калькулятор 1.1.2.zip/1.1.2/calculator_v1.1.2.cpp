#include <iomanip>
#include <iostream>
#include <cmath>
#include <math.h>
#include <stdlib.h>
using namespace std;
string S;
bool ERROR = 1;

bool num_t(char F) { // ����������� ����� �� ���
    if (((F == '0') || (F == '1') || (F == '2') || (F == '3') || (F == '4') || (F == '5') || (F == '6') || (F == '7') || (F == '8') || (F == '9') || (F == ',') || (F == '.')) && (ERROR)) return true;
    else return false;
}

int numeral(char F) { // ����������� �����
    if (ERROR) {
        int a = 0;
        if      (F == '0') a = 0;
        else if (F == '1') a = 1;
        else if (F == '2') a = 2;
        else if (F == '3') a = 3;
        else if (F == '4') a = 4;
        else if (F == '5') a = 5;
        else if (F == '6') a = 6;
        else if (F == '7') a = 7;
        else if (F == '8') a = 8;
        else               a = 9;
        return a;
    }
}

long double number(int& i) { // ����������� ����� � ������� ����� �� ������ � a �� ������� � b (������� �����)
    //
    while ((!num_t(S[i])) && (ERROR)) i++;
    int a = i;
    while ((num_t(S[i])) && (ERROR)) {
        i++;
        if (a + 15 < i) ERROR = 0;
    }
    int b = i - 1;

    long double n = 0;
    int ii = 0;
    while ((b >= a) && (ERROR)) {
        if ((S[b] == '.') || (S[b] == ',')) { // ��������� ������� �����
            while (n >= 1) n /= 10;
            ii = 0;
        }
        else {
            n = n + numeral(S[b])*pow(10, ii);
            ii++;
        }
        b--;
    }
    return n;
}

void calculator() {
    //cout << "YES" << endl;
    int i = 0;
    long double a = number(i);
    char F = S[i];
    long double b = number(i);
    long double c = 0;
    if      (F == '+') c = a + b;
    else if (F == '-') c = a - b;
    else if (F == '*') c = a * b;
    else if (F == '/') c = a / b;
    else if (F == '^') c = pow(a, b);
    //else if (F == '�') c = sqrt(a);
    else c = a;
    if (ERROR) cout << c << endl;
    //else if (F == '^') c = a ^ b;
    //cout << F << endl;
    //n = number(i);
    //cout << n << endl;
}

main () {
    cout << "Hello! This is easy calculator, version 1.1" << endl;
    cout << "If you have a problem enter <help>" << endl; //  or write to me in the mail: bakaj_en_0918@1511.ru
    cout << "If you need escape enter <exit> or click <Enter>" << endl; //  or click <Enter>
    cout << "Enjoy communication :)" << endl;
    cout << "------------------------------" << endl;
    bool global_flag = 1;
    while (global_flag) {
        int i = 0;
        bool help = 0;
        while (S[i] != 0) { S[i] = 0; i++; }
        i = 0;
        getline(cin, S);
        if ((S[0] != 0) && (S[0] != ' ')) {
            //cout << "introduced: "; for(i = 0; S[i] != 0; i++) cout << S[i]; cout << endl; // introduced - ��������
            ERROR = 1;
            i = 0;
            while (S[i] != 0) { // exit
                while ((S[i] != 'e') && (S[i] != 'E') && (S[i] != 0)) i++;
                if (((S[i] == 'e') || (S[i] == 'E')) && ((S[i+1] == 'x') || (S[i+1] == 'X')) && ((S[i+2] == 'i') || (S[i+2] == 'I')) && ((S[i+3] == 't') || (S[i+3] == 'T'))) global_flag = 0;
                i++;
            }
            i = 0;
            while (S[i] != 0) { //
                while ((S[i] != 'h') && (S[i] != 'H') && (S[i] != 0)) i++;
                if (((S[i] == 'h') || (S[i] == 'H')) && ((S[i+1] == 'e') || (S[i+1] == 'E')) && ((S[i+2] == 'l') || (S[i+2] == 'L')) && ((S[i+3] == 'p') || (S[i+3] == 'P'))) help = 1;
                i++;
            }
            if (help) {
                cout << "helper:" << endl;
                cout << "Calculator can: +, -, *, /, ^\n"; // , �(radical)
                cout << "using this form input: <123+234> or <1.3+2.4>\n";

                //cout << "klsdjldsnvs;ldvjnsldvjndfljvndflkjvbn" << endl;
            }
            else if (global_flag) { // calculator
                calculator();
                if (!ERROR) cout << "ERROR\n";
            }

        }
        else global_flag = 0; //cout << "no command" << endl;
        cout << "------------------------------" << endl;
    }
}
