 NOTE: This is an incomplete project. I may decide to spend a lot more time on it if people persist giving it positive attention.

# Perceptron
A flexible artificial neural network builder to analysis performance, and optimise the best model. 

Perceptron is a software that will help researchers, students, and programmers to
design, compare, and test artificial neural networks. As it stands, there are few visual
tools that do this for free, and with simplicity.
<b>This software is largely for educational purposes</b>, allowing people to experiment
and understand how the different parameters within an ANN can result in
different performances and better results. I have not used libraries like TensorFlow specifally so people
can see what goes on lower level, all within the code. 

![screenshotnew](https://user-images.githubusercontent.com/7353547/27341298-c611ba96-55d4-11e7-9da9-9cfd6045ae5c.png)



![untitled](https://cloud.githubusercontent.com/assets/7353547/25346609/effb5106-290f-11e7-8426-788a10fd4e2f.png)
