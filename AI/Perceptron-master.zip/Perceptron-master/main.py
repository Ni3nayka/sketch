from mtTkinter import *
from user_interface_handler import user_interface
import sys

tk_main = Tk()
user_interface = user_interface(tk_main)
tk_main.mainloop()
	
